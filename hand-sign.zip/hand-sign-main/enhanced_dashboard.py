import streamlit as st
import cv2 as cv
import numpy as np
import os
import time
from pathlib import Path
import pandas as pd
from datetime import datetime
from PIL import Image
import json

try:
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision
    USE_NEW_API = True
except:
    try:
        import mediapipe as mp
        USE_NEW_API = False
    except:
        st.error("MediaPipe not installed correctly")

st.set_page_config(
    page_title="Hand Gesture Recognition - Enhanced",
    page_icon="👋",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
    <style>
    .main-header {
        font-size: 3rem;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 2rem;
    }
    .stButton>button {
        width: 100%;
        height: 3rem;
        font-size: 1.2rem;
    }
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .info-box {
        background-color: #d1ecf1;
        border: 1px solid #bee5eb;
        color: #0c5460;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    </style>
""", unsafe_allow_html=True)

BASE_DATA_DIR = "training_data"
MODELS_DIR = "trained_models"
CONFIG_FILE = "gesture_config.json"

class SimpleGestureRecognizer:
    
    
    def __init__(self):
        self.gesture_templates = {}
        self.load_templates()
    
    def load_templates(self):
        
        if not os.path.exists(BASE_DATA_DIR):
            return
        
        for gesture_name in os.listdir(BASE_DATA_DIR):
            gesture_dir = os.path.join(BASE_DATA_DIR, gesture_name)
            if os.path.isdir(gesture_dir):
                images = []
                for img_file in os.listdir(gesture_dir)[:20]:
                    if img_file.endswith('.jpg'):
                        img_path = os.path.join(gesture_dir, img_file)
                        img = cv.imread(img_path)
                        if img is not None:
                            img_resized = cv.resize(img, (100, 100))
                            images.append(img_resized)
                
                if images:
                    self.gesture_templates[gesture_name] = images
    
    def compare_histograms(self, img1, img2):
        
        hsv1 = cv.cvtColor(img1, cv.COLOR_BGR2HSV)
        hsv2 = cv.cvtColor(img2, cv.COLOR_BGR2HSV)
        
        hist1 = cv.calcHist([hsv1], [0, 1], None, [50, 60], [0, 180, 0, 256])
        hist2 = cv.calcHist([hsv2], [0, 1], None, [50, 60], [0, 180, 0, 256])
        
        cv.normalize(hist1, hist1, alpha=0, beta=1, norm_type=cv.NORM_MINMAX)
        cv.normalize(hist2, hist2, alpha=0, beta=1, norm_type=cv.NORM_MINMAX)
        
        return cv.compareHist(hist1, hist2, cv.HISTCMP_CORREL)
    
    def recognize(self, image):
        
        if not self.gesture_templates:
            return None, 0.0
        
        img_resized = cv.resize(image, (100, 100))
        
        best_gesture = None
        best_score = 0.0
        
        for gesture_name, templates in self.gesture_templates.items():
            scores = []
            for template in templates:
                score = self.compare_histograms(img_resized, template)
                scores.append(score)
            
            avg_score = np.mean(scores) if scores else 0.0
            
            if avg_score > best_score:
                best_score = avg_score
                best_gesture = gesture_name
        
        if best_score > 0.2:
            return best_gesture, best_score
        
        return None, 0.0


class SimpleHandDetector:
    
    
    def __init__(self):
        self.bg_subtractor = cv.createBackgroundSubtractorMOG2(history=500, varThreshold=50)
        self.kernel = np.ones((3, 3), np.uint8)
        
    def detect_skin_color(self, image):
        
        hsv = cv.cvtColor(image, cv.COLOR_BGR2HSV)
        
        lower_skin = np.array([0, 20, 70], dtype=np.uint8)
        upper_skin = np.array([20, 255, 255], dtype=np.uint8)
        
        mask = cv.inRange(hsv, lower_skin, upper_skin)
        
        mask = cv.erode(mask, self.kernel, iterations=2)
        mask = cv.dilate(mask, self.kernel, iterations=2)
        mask = cv.GaussianBlur(mask, (5, 5), 0)
        
        return mask
    
    def detect_motion(self, image):
        
        fg_mask = self.bg_subtractor.apply(image)
        fg_mask = cv.threshold(fg_mask, 200, 255, cv.THRESH_BINARY)[1]
        fg_mask = cv.dilate(fg_mask, self.kernel, iterations=2)
        return fg_mask
    
    def detect_hands(self, image):
        
        try:
            skin_mask = self.detect_skin_color(image)
            
            contours, _ = cv.findContours(skin_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
            
            if contours:
                largest_contour = max(contours, key=cv.contourArea)
                area = cv.contourArea(largest_contour)
                
                return {
                    'contour': largest_contour,
                    'area': area,
                    'mask': skin_mask
                }
            
            return None
        except Exception as e:
            return None
    
    def has_hand(self, results, min_area=5000):
        
        if results is None:
            return False
        
        return results.get('area', 0) > min_area


def ensure_directories():
    
    os.makedirs(BASE_DATA_DIR, exist_ok=True)
    os.makedirs(MODELS_DIR, exist_ok=True)


def load_config():
    
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {}


def save_config(config):
    
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def update_gesture_config(gesture_name):
    
    if not gesture_name:
        return

    config = load_config()
    if gesture_name not in config:
        config[gesture_name] = {
            "created": datetime.now().isoformat(),
            "description": f"Gesture: {gesture_name}"
        }
    config[gesture_name]["last_updated"] = datetime.now().isoformat()
    config[gesture_name]["image_count"] = get_gesture_image_count(gesture_name)
    save_config(config)


def get_gesture_list():
    
    if not os.path.exists(BASE_DATA_DIR):
        return []

    gestures = [
        d for d in os.listdir(BASE_DATA_DIR)
        if os.path.isdir(os.path.join(BASE_DATA_DIR, d))
    ]
    return sorted(gestures)


def get_gesture_info(gesture_name):
    
    config = load_config()
    info = config.get(gesture_name, {})
    if "image_count" not in info:
        info["image_count"] = get_gesture_image_count(gesture_name)
    return info


def save_gesture_image(gesture_name, image):
    
    gesture_dir = os.path.join(BASE_DATA_DIR, gesture_name)
    os.makedirs(gesture_dir, exist_ok=True)
    
    existing_images = len([f for f in os.listdir(gesture_dir) if f.endswith('.jpg')])
    
    filename = f"{gesture_name}_{existing_images + 1:04d}.jpg"
    filepath = os.path.join(gesture_dir, filename)
    cv.imwrite(filepath, image)
    
    return filepath, existing_images + 1


def get_gesture_image_count(gesture_name):
    
    gesture_dir = os.path.join(BASE_DATA_DIR, gesture_name)
    if not os.path.exists(gesture_dir):
        return 0
    return len([f for f in os.listdir(gesture_dir) if f.endswith('.jpg')])


def draw_hand_detection(image, results, min_area=5000):
    
    h, w = image.shape[:2]
    
    has_hand = results is not None and results.get('area', 0) > min_area
    
    color = (0, 255, 0) if has_hand else (0, 0, 255)
    status = "✓ HAND DETECTED" if has_hand else "✗ NO HAND - Show your hand"
    
    cv.putText(image, status, (10, 40), 
               cv.FONT_HERSHEY_SIMPLEX, 1.0, color, 3)
    
    thickness = 5 if has_hand else 2
    cv.rectangle(image, (0, 0), (w-1, h-1), color, thickness)
    
    if has_hand and 'contour' in results:
        contour = results['contour']
        
        cv.drawContours(image, [contour], -1, (0, 255, 0), 2)
        
        x, y, bw, bh = cv.boundingRect(contour)
        cv.rectangle(image, (x, y), (x + bw, y + bh), (0, 255, 0), 2)
        
        area = results.get('area', 0)
        cv.putText(image, f"Area: {int(area)}", (10, 80),
                  cv.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    return image


def main():
    st.markdown('<h1 class="main-header">👋 Enhanced Hand Gesture Recognition</h1>', 
                unsafe_allow_html=True)
    
    ensure_directories()
    
    if 'hand_detector' not in st.session_state:
        st.session_state.hand_detector = SimpleHandDetector()
    
    if 'gesture_recognizer' not in st.session_state:
        st.session_state.gesture_recognizer = SimpleGestureRecognizer()
    
    if 'is_capturing' not in st.session_state:
        st.session_state.is_capturing = False
    
    if 'captured_count' not in st.session_state:
        st.session_state.captured_count = 0
    
    if 'min_hand_area' not in st.session_state:
        st.session_state.min_hand_area = 5000
    
    st.sidebar.title("⚙️ Controls")
    
    with st.sidebar.expander("🔧 Detection Settings", expanded=False):
        st.write("**Adjust if hand not detected:**")
        
        min_area = st.slider(
            "Min Hand Area",
            min_value=1000,
            max_value=20000,
            value=5000,
            step=500,
            help="Minimum area to consider as hand"
        )
        
        if 'hand_detector' in st.session_state:
            st.session_state.min_hand_area = min_area
        
        st.info("👋 Show your hand to the camera. If not detected, lower the Min Hand Area slider.")
    
    st.sidebar.markdown("---")
    
    mode = st.sidebar.radio(
        "Select Mode",
        ["📚 Train New Gesture", "🔍 Test & Recognize", "📊 View Training Data"],
        index=0
    )
    
    st.sidebar.markdown("---")
    
    if mode == "📚 Train New Gesture":
        train_mode()
    elif mode == "🔍 Test & Recognize":
        test_mode()
    elif mode == "📊 View Training Data":
        view_data_mode()


def train_mode():
    
    st.header("📚 Train New Gesture")
    
    st.markdown(
        """
        <div class="info-box">
        <b>How it works:</b><br>
        1. Type a name for your gesture (e.g., "hello", "peace", "thumbs_up")<br>
        2. Click "Start Capturing"<br>
        3. Show your hand gesture to the camera<br>
        4. Images are automatically captured when hand is detected<br>
        5. Collect 50-200 images for best results
        </div>
        """,
        unsafe_allow_html=True
    )
    
    col1, col2 = st.columns([2, 1])
    
    with col2:
        st.subheader("⚙️ Training Settings")
        
        gesture_name = st.text_input(
            "Gesture Name",
            value="",
            placeholder="e.g., hello, peace, thumbs_up",
            help="Enter a unique name for this gesture"
        ).strip().lower().replace(" ", "_")
        
        target_images = st.number_input(
            "Target Images",
            min_value=10,
            max_value=500,
            value=100,
            step=10,
            help="Number of images to capture"
        )
        
        capture_delay = st.slider(
            "Capture Delay (seconds)",
            min_value=0.1,
            max_value=2.0,
            value=0.3,
            step=0.1,
            help="Delay between captures"
        )
        
        st.markdown("---")
        
        if gesture_name:
            current_count = get_gesture_image_count(gesture_name)
            st.metric("Images Collected", current_count)
            
            if current_count > 0:
                progress = min(current_count / target_images, 1.0)
                st.progress(progress)
        
        st.markdown("---")
        
        if gesture_name:
            col_start, col_stop = st.columns(2)
            
            with col_start:
                if st.button("▶️ Start Capturing", type="primary", disabled=st.session_state.is_capturing):
                    st.session_state.is_capturing = True
                    st.session_state.captured_count = 0
                    st.rerun()
            
            with col_stop:
                if st.button("⏹️ Stop", disabled=not st.session_state.is_capturing):
                    st.session_state.is_capturing = False

                    update_gesture_config(gesture_name)

                    st.rerun()
        else:
            st.warning("⚠️ Please enter a gesture name first")
        
        if st.session_state.is_capturing:
            st.success(f"🔴 CAPTURING... ({st.session_state.captured_count} captured)")
    
    with col1:
        st.subheader("📹 Camera Feed")
        
        if not gesture_name:
            st.info("👆 Enter a gesture name in the right panel to start")
            return
        
        frame_placeholder = st.empty()
        status_placeholder = st.empty()
        
        if st.session_state.is_capturing:
            cap = cv.VideoCapture(0)
            cap.set(cv.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv.CAP_PROP_FRAME_HEIGHT, 480)
            
            time.sleep(0.5)
            
            last_capture_time = 0
            
            while st.session_state.is_capturing:
                ret, frame = cap.read()
                if not ret:
                    status_placeholder.error("Failed to access camera. Please check camera permissions.")
                    break
                
                frame = cv.flip(frame, 1)
                display_frame = frame.copy()
                
                min_area = st.session_state.get('min_hand_area', 5000)
                
                results = st.session_state.hand_detector.detect_hands(frame)
                has_hand = results is not None and results.get('area', 0) > min_area
                
                display_frame = draw_hand_detection(display_frame, results, min_area)
                
                current_time = time.time()
                if has_hand:
                    if current_time - last_capture_time >= capture_delay:
                        roi = frame
                        if results is not None and 'contour' in results:
                            x, y, w, h = cv.boundingRect(results['contour'])
                            if w > 0 and h > 0:
                                roi = frame[y:y + h, x:x + w]

                        filepath, count = save_gesture_image(gesture_name, roi)
                        st.session_state.captured_count = count
                        last_capture_time = current_time
                        
                        if count >= target_images:
                            st.session_state.is_capturing = False
                            cap.release()
                            update_gesture_config(gesture_name)
                            status_placeholder.success(f"✅ Target reached! Collected {count} images")
                            time.sleep(1)
                            st.rerun()
                
                cv.putText(display_frame, f"Captured: {st.session_state.captured_count}/{target_images}", 
                          (10, display_frame.shape[0] - 20),
                          cv.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                
                frame_rgb = cv.cvtColor(display_frame, cv.COLOR_BGR2RGB)
                frame_placeholder.image(frame_rgb, channels="RGB", use_container_width=True)
                
                if has_hand:
                    status_placeholder.success("✅ Hand detected - capturing images...")
                else:
                    status_placeholder.warning("⚠️ Show your hand to the camera. Adjust 'Min Hand Area' in sidebar if needed.")
                
                time.sleep(0.03)
            
            cap.release()
            
            if gesture_name and get_gesture_image_count(gesture_name) > 0:
                update_gesture_config(gesture_name)
                status_placeholder.success(f"✅ Training session complete! Collected {get_gesture_image_count(gesture_name)} images")
        else:
            status_placeholder.info("Click '▶️ Start Capturing' to begin training")


def test_mode():
    
    st.header("🔍 Test & Recognize Gestures")
    
    gestures = get_gesture_list()
    
    if not gestures:
        st.warning("No gestures trained yet. Train at least one gesture first.")
        return
    
    st.success(
        f"Ready to recognize {len(gestures)} gestures: {', '.join(gestures)}"
    )
    
    if st.button("🔄 Reload Training Data"):
        st.session_state.gesture_recognizer = SimpleGestureRecognizer()
        st.success("Training data reloaded!")
    
    col1, col2 = st.columns([2, 1])
    
    with col2:
        st.subheader("📊 Detection Results")
        gesture_placeholder = st.empty()
        confidence_placeholder = st.empty()
        
        st.markdown("---")
        st.subheader("📝 Trained Gestures")
        for gesture in gestures:
            count = get_gesture_image_count(gesture)
            st.write(f"**{gesture}**: {count} images")
    
    with col1:
        st.subheader("📹 Live Camera")
        
        run_test = st.checkbox("Start Testing", value=False)
        frame_placeholder = st.empty()
        status_placeholder = st.empty()
        
        if run_test:
            cap = cv.VideoCapture(0)
            cap.set(cv.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv.CAP_PROP_FRAME_HEIGHT, 480)
            
            time.sleep(0.5)
            
            stop_button = st.button("⏹️ Stop Testing")
            
            while run_test and not stop_button:
                ret, frame = cap.read()
                if not ret:
                    st.error("Failed to access camera")
                    break
                
                frame = cv.flip(frame, 1)
                display_frame = frame.copy()
                
                min_area = st.session_state.get('min_hand_area', 5000)
                
                results = st.session_state.hand_detector.detect_hands(frame)
                has_hand = results is not None and results.get('area', 0) > min_area
                
                display_frame = draw_hand_detection(display_frame, results, min_area)
                
                detected_gesture = None
                confidence = 0.0
                
                if has_hand:
                    roi = frame
                    if results is not None and 'contour' in results:
                        x, y, w, h = cv.boundingRect(results['contour'])
                        if w > 0 and h > 0:
                            roi = frame[y:y + h, x:x + w]

                    detected_gesture, confidence = st.session_state.gesture_recognizer.recognize(roi)
                    
                    if detected_gesture:
                        cv.putText(display_frame, f"{detected_gesture.upper()}", 
                                  (10, 80), cv.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)
                        cv.putText(display_frame, f"Confidence: {confidence:.1%}", 
                                  (10, 120), cv.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                        
                        with gesture_placeholder.container():
                            st.metric("🎯 Detected Gesture", detected_gesture.upper())
                        
                        with confidence_placeholder.container():
                            st.metric("📊 Confidence", f"{confidence:.1%}")
                        
                        status_placeholder.success(f"✅ Recognized: {detected_gesture}")
                    else:
                        with gesture_placeholder.container():
                            st.metric("🎯 Detected Gesture", "Unknown")
                        status_placeholder.info("Hand detected but gesture not recognized. Show a trained gesture.")
                else:
                    with gesture_placeholder.container():
                        st.metric("🎯 Detected Gesture", "No hand")
                    status_placeholder.warning("Show your hand to the camera")
                
                frame_rgb = cv.cvtColor(display_frame, cv.COLOR_BGR2RGB)
                frame_placeholder.image(frame_rgb, channels="RGB", use_container_width=True)
                
                time.sleep(0.03)
            
            cap.release()


def view_data_mode():
    
    st.header("📊 Training Data Overview")
    
    config = load_config()
    gestures = get_gesture_list()
    
    if not gestures:
        st.warning("No training data collected yet. Start training in **Train New Gesture** mode!")
        return
    
    st.subheader("📈 Summary")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Gestures", len(gestures))
    
    with col2:
        total_images = sum(get_gesture_image_count(g) for g in gestures)
        st.metric("Total Images", total_images)
    
    with col3:
        avg_images = total_images / len(gestures) if gestures else 0
        st.metric("Avg Images/Gesture", f"{avg_images:.0f}")
    
    st.markdown("---")
    
    st.subheader("📋 Gesture Details")
    
    for gesture in gestures:
        with st.expander(f"**{gesture.upper()}**", expanded=False):
            count = get_gesture_image_count(gesture)
            info = get_gesture_info(gesture)
            
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.write(f"**Images Collected:** {count}")
                if "created" in info:
                    st.write(f"**Created:** {info['created'][:10]}")
                if "last_updated" in info:
                    st.write(f"**Last Updated:** {info['last_updated'][:10]}")
                
                gesture_dir = os.path.join(BASE_DATA_DIR, gesture)
                if os.path.exists(gesture_dir):
                    images = sorted([f for f in os.listdir(gesture_dir) if f.endswith('.jpg')])
                    if images:
                        st.write("**Sample Images:**")
                        cols = st.columns(5)
                        for idx, img_name in enumerate(images[:5]):
                            with cols[idx]:
                                img_path = os.path.join(gesture_dir, img_name)
                                img = Image.open(img_path)
                                st.image(img, use_container_width=True)
            
            with col2:
                if st.button(f"🗑️ Delete {gesture}", key=f"del_{gesture}"):
                    import shutil
                    gesture_dir = os.path.join(BASE_DATA_DIR, gesture)
                    if os.path.exists(gesture_dir):
                        shutil.rmtree(gesture_dir)
                    
                    config = load_config()
                    if gesture in config:
                        del config[gesture]
                    save_config(config)
                    
                    st.success(f"Deleted {gesture}")
                    st.rerun()
    
    st.markdown("---")
    
    st.subheader("💾 Data Location")
    st.code(f"Training Data: {os.path.abspath(BASE_DATA_DIR)}")
    st.info("Use the training_data folders as your dataset for training a model.")


if __name__ == "__main__":
    main()
