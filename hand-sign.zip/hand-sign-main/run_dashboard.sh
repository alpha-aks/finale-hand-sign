#!/bin/bash

echo "🚀 Starting Hand Gesture Recognition Dashboard..."
echo ""
echo "Opening Streamlit dashboard in your browser..."
echo ""
echo "Dashboard will be available at: http://localhost:8501"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

cd "$(dirname "$0")"
python3 -m streamlit run streamlit_dashboard.py
